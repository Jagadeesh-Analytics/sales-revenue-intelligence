# Sales & Revenue Intelligence Platform

**Stack:** SQL + Python + Power BI

## Objective
An end-to-end analytics solution to monitor revenue, profit, customers, products, categories and regions.

## Business Questions
- What are total revenue, cost, profit and margin?
- Which regions/categories drive profit?
- What is the monthly sales trend?
- Which customers generate the most revenue?
- Which products have weak margins?
- How do discounts affect profitability?

## Dashboard Pages
1. Executive Overview
2. Sales & Profit Trends
3. Product/Category Analysis
4. Customer Analysis

## Core DAX
```DAX
Total Revenue = SUM(Sales[Revenue])
Total Cost = SUM(Sales[Cost])
Total Profit = SUM(Sales[Profit])
Profit Margin % = DIVIDE([Total Profit], [Total Revenue])
Orders = DISTINCTCOUNT(Sales[Order_ID])
Units Sold = SUM(Sales[Quantity])
Average Order Value = DIVIDE([Total Revenue], [Orders])
```

**Dataset:** Synthetic data created for portfolio/demo purposes.
