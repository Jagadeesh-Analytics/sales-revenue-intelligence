# Power BI Dashboard Guide

Import `data/sales.csv`.

### Model
Create:
```DAX
Date = CALENDAR(MIN(Sales[Order_Date]), MAX(Sales[Order_Date]))
```
Create Year, Month and Month Number columns and relate Date[Date] to Sales[Order_Date].

### Executive Overview
KPI cards: Revenue, Profit, Margin %, Orders, Units Sold.
Charts: Revenue by Month, Profit by Region, Revenue by Category.
Slicers: Date, Region, Category.

### Product Analysis
Product revenue/profit table, margin chart, category slicer.

### Customer Analysis
Top customers by revenue, customer revenue/profit chart, date/region slicers.
