import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("../data/sales.csv", parse_dates=["Order_Date"])
print("Shape:", df.shape)
print("Missing values:\n", df.isna().sum())
print("Duplicate rows:", df.duplicated().sum())

print("\nKPIs")
print("Revenue:", round(df.Revenue.sum(),2))
print("Profit:", round(df.Profit.sum(),2))
print("Margin %:", round(df.Profit.sum()/df.Revenue.sum()*100,2))
print("Orders:", df.Order_ID.nunique())
print("Units:", df.Quantity.sum())

monthly=df.set_index("Order_Date").resample("ME")[["Revenue","Profit"]].sum()
monthly.plot(title="Monthly Revenue and Profit")
plt.tight_layout(); plt.show()

print("\nCategory performance:")
print(df.groupby("Category")[["Revenue","Profit"]].sum().sort_values("Profit",ascending=False))
