-- Load sales.csv into a table named Sales before running these queries.

-- 1. Executive KPIs
SELECT SUM(revenue) total_revenue, SUM(cost) total_cost, SUM(profit) total_profit,
       ROUND(100.0*SUM(profit)/NULLIF(SUM(revenue),0),2) profit_margin_pct,
       COUNT(DISTINCT order_id) orders, SUM(quantity) units_sold
FROM sales;

-- 2. Monthly trend
SELECT DATE_TRUNC('month', order_date) month, SUM(revenue) revenue, SUM(profit) profit
FROM sales GROUP BY 1 ORDER BY 1;

-- 3. Regional performance
SELECT region, SUM(revenue) revenue, SUM(profit) profit
FROM sales GROUP BY region ORDER BY profit DESC;

-- 4. Top customers
SELECT customer_id, SUM(revenue) revenue, SUM(profit) profit
FROM sales GROUP BY customer_id ORDER BY revenue DESC LIMIT 10;

-- 5. Product margin
SELECT product_id, SUM(revenue) revenue, SUM(profit) profit,
       ROUND(100.0*SUM(profit)/NULLIF(SUM(revenue),0),2) margin_pct
FROM sales GROUP BY product_id ORDER BY margin_pct ASC;

-- 6. Discount impact
SELECT discount, SUM(revenue) revenue, SUM(profit) profit
FROM sales GROUP BY discount ORDER BY discount;
