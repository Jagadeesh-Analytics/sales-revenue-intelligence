# Customer Churn Prediction & Retention Analytics

**Stack:** SQL + Python + Power BI

## Objective
Identify customers with higher churn risk and create an actionable retention dashboard.

## Business Questions
- What is the overall churn rate?
- Which contract types churn most?
- Does tenure relate to churn?
- Which customers need retention attention?

## Python Model
The included Python script trains a logistic-regression model and creates a customer risk score.

## Dashboard Pages
1. Churn Overview
2. Risk Monitoring
3. Retention Actions

## DAX
```DAX
Customers = DISTINCTCOUNT(Churn[Customer_ID])
Churned Customers = CALCULATE([Customers], Churn[Churn] = 1)
Churn Rate % = DIVIDE([Churned Customers], [Customers])
Average Monthly Charges = AVERAGE(Churn[Monthly_Charges])
```

**Dataset:** Synthetic portfolio data. Do not present it as real company data.
