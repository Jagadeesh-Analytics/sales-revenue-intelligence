# Power BI Dashboard Guide

Run `python/churn_model.py` first, then import `data/customer_churn_scored.csv`.

### Page 1 — Churn Overview
Cards: Customers, Churned Customers, Churn Rate.
Charts: Churn by Contract Type, Churn by Tenure Band.

### Page 2 — Risk Monitoring
High-risk customer count, risk-segment distribution, and a detailed customer table.

### Page 3 — Retention Actions
Use risk score + contract + support tickets to prioritize outreach.

Important: risk scores indicate model-estimated risk, not certainty.
