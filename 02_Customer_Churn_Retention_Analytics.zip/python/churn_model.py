import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, roc_auc_score

df=pd.read_csv("../data/customer_churn.csv")
X=df.drop(columns=["Customer_ID","Churn"]); y=df["Churn"]
cat=["Contract_Type"]; num=["Tenure_Months","Monthly_Charges","Support_Tickets","Late_Payments"]

prep=ColumnTransformer([("cat",OneHotEncoder(handle_unknown="ignore"),cat),
                        ("num","passthrough",num)])
model=Pipeline([("prep",prep),("clf",LogisticRegression(max_iter=1000))])

Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
model.fit(Xtr,ytr)
proba=model.predict_proba(Xte)[:,1]
print(classification_report(yte,(proba>=.5).astype(int)))
print("ROC-AUC:",round(roc_auc_score(yte,proba),4))

df["Churn_Risk_Score"]=model.predict_proba(X)[:,1]
df["Risk_Segment"]=pd.cut(df.Churn_Risk_Score,[-.01,.30,.60,1.01],
                           labels=["Low","Medium","High"])
df.to_csv("../data/customer_churn_scored.csv",index=False)
