-- Overall churn
SELECT COUNT(DISTINCT customer_id) customers, SUM(churn) churned_customers,
       ROUND(100.0*SUM(churn)/COUNT(*),2) churn_rate_pct
FROM customer_churn;

-- Churn by contract
SELECT contract_type, COUNT(*) customers, SUM(churn) churned,
       ROUND(100.0*SUM(churn)/COUNT(*),2) churn_rate_pct
FROM customer_churn GROUP BY contract_type ORDER BY churn_rate_pct DESC;

-- Churn by tenure
SELECT CASE WHEN tenure_months<12 THEN '<12 months'
            WHEN tenure_months<36 THEN '12-35 months' ELSE '36+ months' END tenure_band,
       COUNT(*) customers, SUM(churn) churned,
       ROUND(100.0*SUM(churn)/COUNT(*),2) churn_rate_pct
FROM customer_churn GROUP BY 1 ORDER BY 1;

-- Customer characteristics
SELECT contract_type, AVG(monthly_charges) avg_charges,
       AVG(support_tickets) avg_tickets, AVG(late_payments) avg_late_payments
FROM customer_churn GROUP BY contract_type;
