# Inventory Demand Forecasting & Optimization

**Stack:** SQL + Python + Power BI

## Objective
Analyze demand, inventory and reorder risk to reduce stock-outs and excess inventory.

## Business Questions
- Which products have the highest demand?
- Which products are at reorder risk?
- What is the monthly demand trend?
- Which products need immediate attention?

## Dashboard Pages
1. Inventory Executive Overview
2. Product Demand & Trends
3. Reorder Risk Monitor

## DAX
```DAX
Units Sold = SUM(Inventory[Units_Sold])
Average Stock = AVERAGE(Inventory[Closing_Stock])
Reorder Risk Items =
CALCULATE(COUNTROWS(Inventory), Inventory[Stock_Status] = "Reorder")
```

**Dataset:** Synthetic portfolio data.
