# Power BI Dashboard Guide

Import `data/inventory.csv`.

### Page 1 — Inventory Overview
Cards: Units Sold, Average Stock, Reorder Risk Items.
Charts: Monthly demand and Reorder vs Sufficient.

### Page 2 — Product Analysis
Top products by units sold, average stock, lead time.

### Page 3 — Reorder Monitor
Table: Product ID, Units Sold, Closing Stock, Reorder Point, Lead Time.
Filter Stock_Status = Reorder.
