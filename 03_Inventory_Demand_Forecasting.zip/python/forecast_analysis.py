import pandas as pd
import matplotlib.pyplot as plt

df=pd.read_csv("../data/inventory.csv",parse_dates=["Date"])
daily=df.groupby("Date",as_index=False)["Units_Sold"].sum()
daily["7D_MA"]=daily.Units_Sold.rolling(7).mean()

print("Top products:")
print(df.groupby("Product_ID").Units_Sold.sum().sort_values(ascending=False).head(10))
print("\nReorder risk:")
print(df[df.Stock_Status=="Reorder"].Product_ID.value_counts().head(10))

daily.plot(x="Date",y=["Units_Sold","7D_MA"],title="Daily Demand and 7-Day Moving Average")
plt.tight_layout(); plt.show()
