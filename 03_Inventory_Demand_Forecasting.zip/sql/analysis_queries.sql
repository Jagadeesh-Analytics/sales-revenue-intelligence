-- Inventory KPIs
SELECT SUM(units_sold) units_sold, AVG(closing_stock) avg_closing_stock,
       SUM(CASE WHEN stock_status='Reorder' THEN 1 ELSE 0 END) reorder_rows
FROM inventory;

-- Product demand
SELECT product_id, SUM(units_sold) units_sold, AVG(closing_stock) avg_stock
FROM inventory GROUP BY product_id ORDER BY units_sold DESC;

-- Reorder risk
SELECT product_id, COUNT(*) reorder_days, AVG(lead_time_days) avg_lead_time
FROM inventory WHERE stock_status='Reorder'
GROUP BY product_id ORDER BY reorder_days DESC;

-- Monthly demand
SELECT DATE_TRUNC('month', date) month, SUM(units_sold) units_sold,
       AVG(closing_stock) avg_stock
FROM inventory GROUP BY 1 ORDER BY 1;
